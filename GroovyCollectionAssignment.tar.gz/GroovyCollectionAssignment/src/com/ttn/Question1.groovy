package com.ttn
/*
Initialize an empty list and give the output of the following code:

        l[11] = "myelement"
println l[11]
println l.get(5)
println l
Initialize a list using a range and find all elements which are even*/

class Question1 {


    static void main(args){
        List list=[]
        list[11]="myelement"
        println list[11]
        println(list.get(5))
        println(list)

        println()
        println("Even Numbers in a List:")
        List even=Arrays.asList(1,2,3,4,5,6,7,8)

            even.each {
                if(it%2==0)
                    println(it)
            }


    }


}
