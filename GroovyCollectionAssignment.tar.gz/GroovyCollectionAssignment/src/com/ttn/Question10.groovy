package com.ttn

//Get first, second and last element of Range.

class Question10 {

    static void main(args){
        Range range=6..10;
        println(range.first())
        println(range.get(1))
        println(range.last())

    }
}
