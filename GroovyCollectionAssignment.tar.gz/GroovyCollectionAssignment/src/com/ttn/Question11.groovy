package com.ttn

//WAP to print the table of a given number

class Question11 {

    static void main(args){

        Scanner sc=new Scanner(System.in)
        println("Enter a number")
        int num
        num=sc.nextInt()

        (1..10).each {
            println "${num} X ${it}= "+ num *it
        }


    }
}
