package com.ttn

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils

//We have a sorted list of alphabets a-z, print all alphabets appearing after j

class Question12 {

    static void main(args){

        Set set='a'..'z'
        set.sort()
        int num=set.size()-1
        (10..num).each {

            println set.getAt(it)

        }


    }
}
