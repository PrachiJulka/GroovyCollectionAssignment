package com.ttn

//Find the number of occurences of a character in a string

class Question13 {

     static void main(args) {

         String str="abcabcde"
         HashMap<Character,Integer> hm=new HashMap<>()
         str.size().times {
             if(hm.containsKey(str.charAt(it)))
                 hm.put(str.charAt(it),hm.get(str.charAt(it))+1)
             else
                 hm.put(str.charAt(it),1)
         }
         println(hm)

    }
}
