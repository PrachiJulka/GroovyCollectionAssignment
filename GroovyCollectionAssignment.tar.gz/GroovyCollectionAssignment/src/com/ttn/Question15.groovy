package com.ttn

/*
Consider a class named "Stack" that holds a list of objects
 and has the following operations associated:

POP - Pops the last element off the stack
PUSH - Pushes an element on top of the stack
TOP - Returns the element at the top of the list Implement the aforesaid class

*/


class Question15 {

    static void main(args){
       Stack obj=new Stack(4)
        Scanner scanner=new Scanner(System.in)
        int c;
        while (c!=4){
            println("Enter 1 to push")
            println("Enter 2 to pop")
            println("Enter 3 to Peek")
            println("Enter 4 to exit")
            println("Enter your choice")
            c=scanner.nextInt()


            switch(c){
                case 1:println("Enter a number to push")
                    obj.push(scanner.nextInt())
                    break

                case 2:
                    println("Popped Element is:"+obj.pop())
                    break

                case 3:
                    println("Top element on stack:"+ obj.top())
                    break


                default:
                    println("Please Enter Correct Choice")
            }

        }
    }
}
class Stack{
    int top
    int size
    int[] stack

     Stack(int arraySize){
        size=arraySize
        stack= new int[size]
        top=-1
    }

    void push(int value){
        if(top==size-1){
            println("Stack is full, can't push a value")
        }
        else if(top==-1){

            top=top+1
            stack[top]=value


        }

        else
        {
            top=top+1
            stack[top]=value


        }
    }

    int pop(){

        int num=stack[top]
        top=top-1

        return num
    }
    int top(){
        return stack[top]
    }
}
