package com.ttn

//Create a new map consisting of 10 of your friend's name's as keys and their ages as value.


class Question16 {


    static void main(args){
        Map<String,Integer> hm=new HashMap<>()
        hm.put("Chunky",22)
        hm.put("Sahil",21)
        hm.put("Vaibhav",22)
        hm.put("Payal",24)
        hm.put("Kamini",24)
        hm.put("Neha",25)
        hm.put("Shraddha", 25)
        hm.put("Kajal",25)
        hm.put("Shrishty",22)
        hm.put("Manhar",25)
        println(hm)
    }


}
