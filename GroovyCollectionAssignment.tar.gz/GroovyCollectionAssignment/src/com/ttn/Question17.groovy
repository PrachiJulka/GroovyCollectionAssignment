package com.ttn
//Create a new map by adding two existing maps


class Question17 {
    static void main(args){

       Map<String,Integer> map=new HashMap<>()
       Map<String,Integer> map1=new HashMap<>()
        map1.put("Chunky",22)

        Map<String,Integer>map2=new HashMap<>()
        map2.put("Sahil",21)


        map.putAll(map1)
        map.putAll(map2)
        println map

    }
}
