package com.ttn

//Try the following code on a map: println map.class println map.getClass() What do you observe?

class Question18 {

    static void main(args){
        Map<String,Integer> map=new HashMap<>()
        map.put("Chunky",22)

        println map.getClass()
        println map.class=10

    }

}
