package com.ttn

//Consider the following map: Map m = ['1' : 2, '2' : 3, '3' : 4, '2':5]
// Is this a valid construction? What is the value of m['2']?

class Question19 {

    static void main(args){
        Map m = ['1' : 2, '2' : 3, '3' : 4, '2':5]
        println m['2']
    }
}
