package com.ttn

/*
Create a set from a list containing duplicate elements. What do you observe?
How can you achieve the same result without converting a list to a set?
*/



class Question2 {

    static void main(args){
        List list=[1,2,3,3,5,6,7,7,7]

        Set set=new HashSet(list)
        set.each {
            println it
        }

       list.unique()
println(list)
       // println(list.unique())
              //  {it}
       // println list
    }

}
