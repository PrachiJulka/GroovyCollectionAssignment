package com.ttn
//Find if a map contains a particular key.
class Question20 {

    static void main(args){
        Map map=['1' : 2, '2' : 3, '3' : 4, '2':5]
        if(map.containsKey('1'))
            println("true")
        else
            println("false")
    }
}
