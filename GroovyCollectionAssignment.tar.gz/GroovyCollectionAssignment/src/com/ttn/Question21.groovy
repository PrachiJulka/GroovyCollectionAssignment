package com.ttn

/*
Consider the following map: Map m = [‘Computing’ : [‘Computing’ : 600, ‘Information Systems’
 : 300], ‘Engineering’ : [‘Civil’ : 200, ‘Mechanical’ : 100], ‘Management’ :
 [‘Management’ : 800] ]

How many university departments are there?
        How many programs are delivered by the Computing department?
        How many students are enrolled in the Civil Engineering program?

*/


class Question21 {

    static void main(args){
        Map m = ["Computing" : ["Computing" : 600, "Information Systems"
                                : 300], "Engineering" : ["Civil" : 200, "Mechanical" : 100], "Management" :
                 ["Management" : 800] ]

        println("University Departments:")
        m.each {
            println(it.getKey())


        }
        int count=0
        println("Programs delivered by the computing department")
        m.each {
            if (it.getKey().equals("Computing"))
                it.getValue().each {
                    count++
                }
        }

        println(count)

      
        println("Students Enrolled in Civil Engineering program")
        m.each {
            if(it.getKey().equals("Engineering"))
                it.getValue().every {
                    println(it)
               }
                }
        }
    }

