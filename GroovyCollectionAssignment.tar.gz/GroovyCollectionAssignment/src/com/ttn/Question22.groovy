package com.ttn

/*
Conside a class named "Employee" which has the following properties:
1) Name 2) Age 3) DepartmentName
4) EmployeeNumber 5) Salary Let's say that
there's a list of 50 employees available.
Perform the following operations on the list of employees:
Group the employees on the basis of the bracket in which their salary falls.
The ranges are 0-5000, 5001 and 10000, and so on.
Get a count of the number of employees in each department
Get the list of employees whose age is between 18 and 35
Group the employees according to the alphabet with which their first name starts
and display the number of employees in each group whose age is greater than
Group the employees according to their department.
*/


class Question22 {

    static void main(args){
        List<Employees> list = new ArrayList<>()

        Employees e1=new Employees()
        e1.setAge(20)
        e1.setName("Rachel")
        e1.setSalary(2000.00)
        e1.setDepartmentName("Finance")
        e1.setEmployeeNumber(1)

        Employees e2=new Employees()
        e2.setAge(25)
        e2.setName("Ross")
        e2.setSalary(3000.00)
        e2.setEmployeeNumber(2)
        e2.setDepartmentName("Finance")

        Employees e3=new Employees()
        e3.setAge(40)
        e3.setName("Chandler")
        e3.setSalary(7000.00)
        e3.setDepartmentName("Sales")
        e3.setEmployeeNumber(3)

        Employees e4=new Employees()
        e4.setAge(50)
        e4.setName("Joey")
        e4.setSalary(8000.00)
        e4.setDepartmentName("IT")
        e4.setEmployeeNumber(4)


        Employees e5=new Employees()
        e5.setAge(22)
        e5.setName("Monica")
        e5.setSalary(9000.00)
        e5.setEmployeeNumber(5)
        e5.setDepartmentName("HR")

        Employees e6=new Employees()
        e6.setAge(27)
        e6.setName("Phoebe")
        e6.setSalary(10000.00)
        e6.setDepartmentName("HR")
        e6.setEmployeeNumber(6)

        Employees e7=new Employees()
        e7.setAge(26)
        e7.setName("Prachi")
        e7.setSalary(12000.00)
        e7.setDepartmentName("IT")
        e7.setEmployeeNumber(7)

        Employees e8=new Employees()
        e8.setAge(21)
        e8.setName("Barney")
        e8.setSalary(9000.00)
        e8.setEmployeeNumber(8)
        e8.setDepartmentName("Sales")

        Employees e9=new Employees()
        e9.setAge(20)
        e9.setName("Lily")
        e9.setSalary(6000.00)
        e9.setDepartmentName("Marketing")
        e9.setEmployeeNumber(9)

        Employees e10=new Employees()
        e10.setAge(31)
        e10.setName("Marchel")
        e10.setSalary(4000.00)
        e10.setDepartmentName("Marketing")
        e10.setEmployeeNumber(10)

        list.add(e1)
        list.add(e2)
        list.add(e3)
        list.add(e4)
        list.add(e5)
        list.add(e6)
        list.add(e7)
        list.add(e8)
        list.add(e9)
        list.add(e10)

        //Grouping employee on basis of salary
        println("---------------------------------------------------------")
        println("Grouping employee on basis of salary")
        println("---------------------------------------------------------")

        Map map = list.groupBy {
            it.salary > 5000
        }
        println(map.entrySet())


        println("---------------------------------------------------------")
        println("Get a count of the number of employees in each department")
        println("-------------------------------------------------")
        Map<String, List> map1 = list.groupBy {
            it.departmentName
        }

        map1.each {
            print("Department Name = " + it.getKey())
            println("-> number of employee: " + it.getValue().size())
        }

        println("-------------------------------------------------")
        //Get the employee between 18 to 35

        println("Get the employee between 18 to 35")
        println("-------------------------------------------------")
        List<Employee> age = []
        Map map3 = list.groupBy {
            it.age > 18 && it.age < 35
        }.each {
            if(it.key==true)
            age.add(it.value)
        }

        println(age.name)


        //Group the employees according to the alphabet with which their first name starts
        //and display the number of employees in each group whose age is greater than

        println("-----------------------------------------------------------------")
        println("Group the employees according to the alphabet with which their first name starts and display the number of employees in each group whose age is greater than")
        println("-----------------------------------------------------------------")
        def list3=list.findAll{ it.age>18}
        list3=list3.groupBy({it.name.charAt(0)})
        println(list3)


       // Group employees according to department
        println("-----------------------------------------------------------------")
        println("Group employees according to department")
        println("-----------------------------------------------------------------")
        Map map5 = list.groupBy {
            it.departmentName
            }
       map5.each {
            print("Department Name = " + it.getKey())
            println("-> Employee="+it.getValue())
            println("---------------------------------------------")
        }

    }




}
/*

1) Name 2) Age 3) DepartmentName
4) EmployeeNumber 5) Salary
*/
class Employees{

    String name
    int age
    String departmentName
    int employeeNumber
    double salary


    @Override
    public String toString() {
        return "Employees{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", departmentName='" + departmentName + '\'' +
                ", employeeNumber=" + employeeNumber +
                ", salary=" + salary +
                '}';
    }
}