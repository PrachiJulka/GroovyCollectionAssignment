package com.ttn

//Write a method which retruns the value of
// passed key from a search string of the form
// "http://www.google.com?name=johny&age=20&hobby=cricket"

class Question23 {

static void main(args){
    String str="http://www.google.com?name=johny&age=20&hobby=cricket"

    URL url = new URL(str)
    String str1=url.getQuery()
    def map=[:]

    str1.splitEachLine("&"){

        it.each{ x ->

            def keyValue = x.split("=")
           map.put(keyValue[0],keyValue[1])

        }

    }

    println(map.entrySet())

}


}
