package com.ttn

//Given two lists [11, 12, 13, 14] and [13, 14, 15],
// how would we obtain the list of items from the first that are not in the second?


class Question3 {

    static void main(args){
        List list=['l1','l2','l3','l4']
        List list1=['l3','l4','l5']

        println(list-list1)

    }
}
