package com.ttn

//Find whether two lists have a common element or not

class Question4 {


    static void main(args){
        List list=[1,2,3,4]
        List list1=[1,2,6,7]

        println(list.intersect(list1))
    }
}
