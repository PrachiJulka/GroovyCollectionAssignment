package com.ttn

//Remove all records from a list whose index is odd

class Question5 {

    static void main(args){
        List list=[1,2,3,4,5,6]
        int i=0
        Iterator itr = list.iterator()
        while(itr.hasNext()){
            itr.next()
            if(i%2!=0)
            itr.remove()

            i++
        }


        println(list)

    }



}
