package com.ttn
//Sort the given list in descending order having distinct elements:
// [14,12, 11,10, 16, 15,12, 10, 99, 90, 14, 16, 35]
class Question7 {

    static void main(args){
        List list=[9,4,4,3,8,0]
        list.unique()
        list.sort{
            -it
        }
        println(list)
    }

}
