package com.ttn

/*
Consider a class Employee with following details * Name * Age *
Salary Create a list consisting of 10 Employee objects.
Get a list of employees who earn less than 5000
Get the name of the youngest employee and oldest employee
Get the employee with maximum salary
Get the list of names of all the employees
*/



class Question8 {

    static void main(args){
        List<Employee> list=new ArrayList<>()

        Employee e1=new Employee()
        e1.setAge(20)
        e1.setName("Rachel")
        e1.setSalary(2000.0)

        Employee e2=new Employee()
        e2.setAge(25)
        e2.setName("Ross")
        e2.setSalary(3000.0)

        Employee e3=new Employee()
        e3.setAge(40)
        e3.setName("Chandler")
        e3.setSalary(7000.0)
        Employee e4=new Employee()
        e4.setAge(50)
        e4.setName("Joey")
        e4.setSalary(8000.0)

        Employee e5=new Employee()
        e5.setAge(22)
        e5.setName("Monica")
        e5.setSalary(9000.0)

        Employee e6=new Employee()
        e6.setAge(27)
        e6.setName("Phoebe")
        e6.setSalary(10000.0)

        Employee e7=new Employee()
        e7.setAge(26)
        e7.setName("Prachi")
        e7.setSalary(12000.0)

        Employee e8=new Employee()
        e8.setAge(21)
        e8.setName("Barney")
        e8.setSalary(9000.0)

        Employee e9=new Employee()
        e9.setAge(20)
        e9.setName("Lily")
        e9.setSalary(6000.0)

        Employee e10=new Employee()
        e10.setAge(31)
        e10.setName("Marchel")
        e10.setSalary(4000.0)

        list.add(e1)
        list.add(e2)
        list.add(e3)
        list.add(e4)
        list.add(e5)
        list.add(e6)
        list.add(e7)
        list.add(e8)
        list.add(e9)
        list.add(e10)

        list.sort{
            it.getAge()
        }

        int youngest =list.get(0).getAge()
        int oldest=list.get(9).getAge()

        list.each {
            if(it.getAge()==youngest)
                println("Youngest Employee: "+it.getName())
            if(it.getAge()==oldest)
                println("Oldest Employee: "+it.getName())

        }

        list.each {
            if(it.getSalary()<5000.00)
                println("Salary less than 5000: "+it.getName())
        }
       double max=list.salary.max()
        list.each {
            if(it.getSalary()==max)
                println("Maximum Salary: "+it.getName())
        }
        println("List of all employees name: ")
        list.each {
            println(it.getName())
        }

    }

}

class Employee{

    String name
    int age
    double salary

}
