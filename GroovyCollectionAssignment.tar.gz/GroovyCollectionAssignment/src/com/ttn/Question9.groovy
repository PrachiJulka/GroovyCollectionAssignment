package com.ttn
/*

Consider the following piece of code: String s = "this string needs to be split"

println s.tokenize(" ")
println s.tokenize()

Compare this with the following code:

        String s = "this string needs to be split"
println s.split(" ")
println s.split(/\s/) (Try Same Parameter with tokenize)

Also try the following exercise:

String s = "are.you.trying.to.split.me.mister?"
s.tokenize(".") s.split(".")
*/



class Question9 {

    static  void main(args){
        String s="this string needs to be split"
        println(s.tokenize(" "))
        println(s.tokenize())
        println(s.tokenize(/\s/))
        println(s.split(""))
        println(s.split(/\s/))

        String s1 = "are.you.trying.to.split.me.mister?"
        println s1.tokenize(".")
        println s1.split(".")

/*        for(String str1:str)
            println(str1)
    */}

}
